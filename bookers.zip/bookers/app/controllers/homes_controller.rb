class HomesController < ApplicationController
  
  
  
  
  
end
